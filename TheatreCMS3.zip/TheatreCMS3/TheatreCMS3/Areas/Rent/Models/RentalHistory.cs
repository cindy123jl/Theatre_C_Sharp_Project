﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheatreCMS3.Areas.Rent.Models
{
    public class RentalHistory
    {
        public int Id { get; set; }
        public bool RentalDamaged  { get; set; }
        public string DamagesIncurred { get; set; }
        public string Rental { get; set; }
    }
}